package tests;

import org.junit.jupiter.api.Test;
import model.*;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class ItemOrderTest {
    final private static Item ITEM_TWO_ARGS = new Item("Test Name", BigDecimal.valueOf(3));
    final private static Item ITEM_FOUR_ARGS = new Item("Test Name", BigDecimal.valueOf(3), 3, BigDecimal.valueOf(3));

    final private static ItemOrder ITEM_ORDER_ONE = new ItemOrder(ITEM_TWO_ARGS, 3);
    final private static ItemOrder ITEM_ORDER_TWO = new ItemOrder(ITEM_FOUR_ARGS, 3);

    @Test
    void constructorExpectedItemTwoArgs() {
        assertSame(ITEM_TWO_ARGS, ITEM_ORDER_ONE.getItem());
    }
    @Test
    void constructorExpectedQuantityFromItemTwoArgs() {
        assertSame(3, ITEM_ORDER_ONE.getQuantity());
    }

    @Test
    void constructorExpectedItemFourArgs() {
        assertSame(ITEM_FOUR_ARGS, ITEM_ORDER_TWO.getItem());
    }
    @Test
    void constructorExpectedQuantityFromItemFourArgs() {
        assertSame(3, ITEM_ORDER_TWO.getQuantity());
    }

    @Test
    void constructorExpectedItemIsNull() {
        assertThrows(NullPointerException.class, () -> {
            final ItemOrder itemOrderNullItem = new ItemOrder(null, 3);
        });
    }

    @Test
    void constructorExpectedQuantityIsZeroForItemTwoArgs() {
        assertThrows(IllegalArgumentException.class, () -> {
            final ItemOrder itemOrderZeroQuantity = new ItemOrder(ITEM_TWO_ARGS, 0);
        });
    }

    @Test
    void constructorExpectedQuantityIsZeroForItemFourArgs() {
        assertThrows(IllegalArgumentException.class, () -> {
            final ItemOrder itemOrderZeroQuantity = new ItemOrder(ITEM_FOUR_ARGS, 0);
        });
    }


    @Test
    void getItemForItemTwoArgs() {
        assertSame(ITEM_TWO_ARGS, ITEM_ORDER_ONE.getItem());
    }

    @Test
    void getItemForItemFourArgs() {
        if (ITEM_FOUR_ARGS.isBulk()) {
            assertSame(ITEM_FOUR_ARGS, ITEM_ORDER_TWO.getItem());
        }
    }

    @Test
    void getQuantityItemOne() {
        assertEquals(3, ITEM_ORDER_ONE.getQuantity());
    }

    @Test
    void getQuantityItemTwo() {
        assertEquals(3, ITEM_ORDER_TWO.getQuantity());
    }

    @Test
    void toStringItemOrderOne() {
        assertEquals("You have made some orders! "
                + "You bought: " + ITEM_ORDER_ONE.getItem(), ITEM_ORDER_ONE.toString());
    }

    @Test
    void toStringItemOrderTwo() {
        assertEquals("You have made some orders! "
                + "You bought: " + ITEM_ORDER_TWO.getItem(), ITEM_ORDER_TWO.toString());
    }
}