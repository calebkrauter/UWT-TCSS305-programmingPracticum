package tests;

import org.junit.jupiter.api.*;
import model.*;
import java.math.BigDecimal;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;

class ItemTest {

    final private static Item ITEM_TWO_ARGS = new Item("Test Name", BigDecimal.valueOf(3));
    final private static Item ITEM_FOUR_ARGS = new Item("Test Name", BigDecimal.valueOf(3), 3, BigDecimal.valueOf(3));
    final private static Item ITEM_HASH_CODE_TESTING = new Item ("Test Name", BigDecimal.valueOf(3));

    @Test
    void constructorTwoArgsExpectedName() {
        assertEquals("Test Name", ITEM_TWO_ARGS.getName());
    }

    @Test
    void constructorTwoArgsExpectedPrice() {
        assertEquals(BigDecimal.valueOf(3), ITEM_TWO_ARGS.getPrice());
    }

    @Test
    void constructorTwoArgsNullName() {
        assertThrows(NullPointerException.class, () -> {
            final Item testTwoArgsNullName = new Item(null, BigDecimal.valueOf(3));
        });
    }

    @Test
    void constructorTwoArgsNullPrice() {
        assertThrows(NullPointerException.class, () -> {
            final Item testTwoArgsNullPrice = new Item("Test Name", null);
        });
    }

    @Test
    void constructorFourArgsNullName() {
        assertThrows(NullPointerException.class, () -> {
            final Item testFourArgsNullName = new Item(null, BigDecimal.valueOf(3), 3, BigDecimal.valueOf(3));
        });
    }

    @Test
    void constructorFourArgsNullPrice() {
        assertThrows(NullPointerException.class, () -> {
            final Item testFourArgsNullPrice = new Item("Test Name", null, 3, BigDecimal.valueOf(3));
        });
    }

    @Test
    void constructorFourArgsNullBulkQuantity() {
        assertThrows(IllegalArgumentException.class, () -> {
            final Item testFourArgsNullBulkQuantity = new Item("Test Name", BigDecimal.valueOf(3), 0, BigDecimal.valueOf(3));
        });
    }

    @Test
    void constructorFourArgsNullBulkPrice() {
        assertThrows(NullPointerException.class, () -> {
            final Item testFourArgsNullBulkPrice = new Item("Test Name", BigDecimal.valueOf(3), 3, null);
        });
    }

    @Test
    void constructorFourArgsExpectedName() {
        assertEquals("Test Name", ITEM_FOUR_ARGS.getName());
    }

    @Test
    void constructorFourArgsExpectedPrice() {
        assertEquals(BigDecimal.valueOf(3), ITEM_FOUR_ARGS.getPrice());
    }

    @Test
    void constructorFourArgsExpectedBulkQuantity() {
        assertEquals(3, ITEM_FOUR_ARGS.getBulkQuantity());
    }

    @Test
    void constructorFourArgsExpectedBulkPrice() {
        assertEquals(BigDecimal.valueOf(3), ITEM_FOUR_ARGS.getBulkPrice());
    }

    @Test //issues with static method being called....
    void getPrice() {
        assertEquals(BigDecimal.valueOf(3), ITEM_TWO_ARGS.getPrice());
    }

    @Test
    void getBulkQuantity() {
        assertEquals(3, ITEM_FOUR_ARGS.getBulkQuantity());
    }

    @Test
    void getBulkPrice() {
        assertEquals(BigDecimal.valueOf(3), ITEM_FOUR_ARGS.getBulkPrice());
    }

    @Test
    void isBulk() {
         assertTrue(ITEM_FOUR_ARGS.isBulk());
         assertFalse(ITEM_TWO_ARGS.isBulk());
    }

    @Test
    void testIsNotBulkToString() {
        String expectedIsNotBulk = (ITEM_TWO_ARGS.getName() + ", " + ITEM_TWO_ARGS.getPrice());
        assertEquals(expectedIsNotBulk, ITEM_TWO_ARGS.toString());
    }

    @Test
    void testIsBulkToString(){
        String expectedIsBulk = ("Test Name, " + 3 + " (" + ITEM_FOUR_ARGS.getBulkQuantity() + " for $" + ITEM_FOUR_ARGS.getBulkPrice() + ")");
        assertEquals(expectedIsBulk, ITEM_FOUR_ARGS.toString());
    }
    // FINISH ALL EQUALS TESTING // Double check
    // Check if I should use methods before each or after each or befor all and after all
    @Test
    void equalsTheOtherObjectIsNull() {
        final Object otherObject = new Object();
        assertFalse(ITEM_TWO_ARGS.equals(otherObject));
    }

    @Test
    void testGetClassNotEqualToTheOtherObjectGetClass() {

    }

    @Test
    void testHashCode() {
        assertEquals(ITEM_HASH_CODE_TESTING.hashCode(), ITEM_TWO_ARGS.hashCode());
    }
}