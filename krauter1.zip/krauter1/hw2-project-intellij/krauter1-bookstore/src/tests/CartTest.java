package tests;

import model.*;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;


class CartTest {

    final private static Cart CART = new Cart();
    final private static Item ITEM_TWO_ARGS = new Item("Test Name",  BigDecimal.valueOf(3));
    final private static Item ITEM_FOUR_ARGS = new Item("Test Name",  BigDecimal.valueOf(3), 6, BigDecimal.valueOf(3));
    final private static Item ITEM_FOUR_ARGS_TWO = new Item("Test Name 2", BigDecimal.valueOf(4), 7, BigDecimal.valueOf(4));
    final private static ItemOrder ITEM_ORDER_ONE = new ItemOrder(ITEM_TWO_ARGS, 6);
    final private static ItemOrder ITEM_ORDER_THREE = new ItemOrder(ITEM_FOUR_ARGS_TWO, 7);


    @Test
    void addTestTheOrderThrowsForNull() {
        assertThrows(NullPointerException.class, () -> CART.add(null));
    }

    @Test
    void addItemNotNull() {
        assertNotNull(ITEM_ORDER_ONE);
    }

    // Removing this test on submission two.
    // Testing Membership in Calculate Total Test
    // @Test
    // void setMembershipTrue() {
    // assertTrue(CART.checkMyMembership());
    // }

//    @Test
//    void setMembershipFalse() {
//        assertFalse(CART.checkMyMembership());
//    }

    // Test added for submission 2
    @Test
    void calculateTotalForMultipleItemsOfEqualType() {
        CART.add(ITEM_ORDER_ONE);
        CART.add(ITEM_ORDER_THREE);
        assertEquals(2, CART.getCartSize());
    }

    // Test added for submission 2
    @Test
    void calculateTotalForEqualItemsOfEqualType() {
        CART.add(ITEM_ORDER_ONE);
        CART.add(ITEM_ORDER_ONE);
        assertEquals(2, CART.getCartSize());
    }

    // Test added for submission 2
    @Test
    void testCalculateTotalNotAMember() {
        assertFalse(ITEM_TWO_ARGS.isBulk());
    }

    // Test added for submission 2
    @Test
    void testCalculateTotalIsAMember() {
        assertTrue(ITEM_FOUR_ARGS.isBulk());
    }

    // Test added for submission 2
    @Test
    void testCalculateTotalIsNotBulk() {
        assertFalse(ITEM_TWO_ARGS.isBulk());
    }

    // Test added for submission 2
    @Test
    void testCalculateTotalIsBulk() {
        assertTrue(ITEM_FOUR_ARGS.isBulk());
    }

    // Test added for submission 2
    @Test
    void testCalculateTotalUpdateTotalWhenMemberAndIsBulk() {
        boolean myMembership = false;
        if (ITEM_FOUR_ARGS.isBulk()) {
            CART.setMembership(true);
            myMembership = true;
        }
        if (myMembership && ITEM_FOUR_ARGS.isBulk()) {
            CART.add(ITEM_ORDER_THREE);
                assertEquals(BigDecimal.valueOf(22).setScale(2, java.math.BigDecimal.ROUND_HALF_EVEN), CART.calculateTotal());
        }
    }

    // Test added for submission 2
    @Test
    void testCalculateTotalUpdateTotalWhenMemberIsFalseAndIsBulkIsFalse() {
        boolean myMembership = true;
        if (!(ITEM_TWO_ARGS.isBulk())) {
            CART.setMembership(false);
            myMembership = false;
        }
        if ((!myMembership && !(ITEM_TWO_ARGS.isBulk()))) {
            CART.add(ITEM_ORDER_THREE);
            assertEquals(BigDecimal.valueOf(46).setScale(2, java.math.BigDecimal.ROUND_HALF_EVEN), CART.calculateTotal());
        }
    }

    // Test added for submission 2
    @Test
    void testCalculateTotalUpdateTotalWhenMembershipIsFalseAndBulkIs() {
        boolean myMembership = true;
        if (!(ITEM_FOUR_ARGS.isBulk())) {
            CART.setMembership(false);
            myMembership = false;
        }
        if ((!myMembership || !(ITEM_FOUR_ARGS.isBulk()))) {
            CART.add(ITEM_ORDER_THREE);
            assertEquals(BigDecimal.valueOf(28.00).setScale(2, java.math.BigDecimal.ROUND_HALF_EVEN), CART.calculateTotal());
        }
    }

    // Test added for submission 2
    @Test
    void testCalculateTotalUpdateTotalWhenMembershipIsTrueAndBulkIsFalse() {
        boolean myMembership = false;
        if (!(ITEM_TWO_ARGS.isBulk())) {
            CART.setMembership(true);
            myMembership = true;
        }

        if ((!myMembership || (ITEM_TWO_ARGS.isBulk()))) {
            CART.add(ITEM_ORDER_THREE);
            assertEquals(BigDecimal.valueOf(28.00).setScale(2, java.math.BigDecimal.ROUND_HALF_EVEN), CART.calculateTotal());
        }
    }

    // Test made on submission two.
    @Test
    void calculateTotalWhenCartIsEmpty() {
        CART.clear();
        if (CART.getCartSize() == 0) {
            assertEquals(BigDecimal.valueOf(0).setScale(2, java.math.BigDecimal.ROUND_HALF_EVEN), CART.calculateTotal());
        }
    }

    // Test made on submission two.
    @Test
    void calculateTotalWithOneItem() {
        CART.clear();
        CART.add(ITEM_ORDER_ONE);
        assertEquals(BigDecimal.valueOf(18).setScale(2, java.math.BigDecimal.ROUND_HALF_EVEN), CART.calculateTotal());
    }

    @Test
    void clear() {
        CART.clear();
        assertEquals(0, CART.getCartSize());
    }

    // Test made on submission two.
    @Test
    void getCartSizeWhenOneItemAdded() {
        CART.clear();
        CART.add(ITEM_ORDER_ONE);
        assertEquals(1, CART.getCartSize());
    }

    // Test made on submission two.
    @Test
    void getCartSizeWhenItemsAreNotEqual() {
        CART.add(ITEM_ORDER_ONE);
        assertEquals(1, CART.getCartSize());
        CART.add(ITEM_ORDER_THREE);
        assertEquals(2, CART.getCartSize());
    }

    // Test made on submission two.
    @Test
    void getCartSizeWhenTwoOfSameItemOrdersPassed() {
        CART.add(ITEM_ORDER_ONE);
        assertEquals(1, CART.getCartSize());
        CART.add(ITEM_ORDER_ONE);
        assertEquals(1, CART.getCartSize());
    }

    // Test made on submission two.
    @Test
    void testToStringIfCartEmpty() {
        CART.clear();
        CART.add(ITEM_ORDER_ONE);
        if (CART.getCartSize() == 0) {
            String expected = "Your Cart\nIs Empty! Please purchase some candy... :(";
            assertEquals(expected, CART.toString());
        }
    }

    // Test made on submission two.
    @Test
    void testToStringIfCartIsNotEmptyAndQuantityGreaterThanOne() {
        CART.clear();
        CART.add(ITEM_ORDER_ONE);
        String expected;
        String expected2;
        if (CART.getCartSize() > 0) {
            expected = "Your Cart\ncontains: " + ITEM_ORDER_ONE.getQuantity() + " " + ITEM_ORDER_ONE.getItem() + " ";
            if (ITEM_ORDER_ONE.getQuantity() > 1) {
                expected2 = "items.";
            } else {
                expected2 = "item.";
            }
            expected = expected + expected2;
            assertEquals(expected, CART.toString());
        }
    }

    // Test made on submission two.
    // This test looks at the case when quantity is one to satisfy
    // the else statement in the nested if statement
    @Test
    void testToStringIfCartIsNotEmptyAndQuantityOne() {
        final ItemOrder itemOrderQuantityOne = new ItemOrder(ITEM_TWO_ARGS, 1);
        CART.clear();
        CART.add(itemOrderQuantityOne);
        String expected = "";
        String expected2 = "";
        if (CART.getCartSize() > 0) {
            expected = "Your Cart\ncontains: " + itemOrderQuantityOne.getQuantity() + " " + itemOrderQuantityOne.getItem() + " ";
            if (itemOrderQuantityOne.getQuantity() > 1) {
                expected2 = "items.";
            } else {
                expected2 = "item.";
            }
            expected = expected + expected2;
            assertEquals(expected, CART.toString());
        }
    }
}