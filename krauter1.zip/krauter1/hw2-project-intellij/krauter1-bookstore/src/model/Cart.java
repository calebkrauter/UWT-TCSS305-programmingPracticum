/*
 * TCSS 305 Assignment 2 - UW Bookstore
 */

package model;

// import jdk.internal.access.JavaSecurityAccess;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

// Javadoc added for submission 2
/**
 * Cart takes information from the ItemOrder class
 * and Item class to make calculations and save values
 * so that the items' info and price calculations may
 * be displayed to the user.
 *
 * @author Caleb Krauter
 * @version November, 02 2022
 */
public class Cart {

    /**
     * myCart is a hashmap used for storing an item order and a quantity.
     */
    private final Map<Item, Integer> myCart;

    /**
     * myMembership is the variable that the setMembership() stores
     * a boolean value in at the class level to show that the
     * membership button was pressed or not pressed.
     */
    private boolean myMembership;


    /**
     * Constructor that creates an empty
     * shopping cart hash map.
     */
    public Cart() {
        myCart = new HashMap<>();
    }

    // Updated this Javadoc on submission 2.
    /**
     * Adds an order to the cart.
     * @param theOrder of type ItemOrder is the current passed order
     */
    public void add(final ItemOrder theOrder) {
        if (theOrder == null) {
            throw new NullPointerException("The order passed into the add method is null.");
        }

        myCart.put(theOrder.getItem(), theOrder.getQuantity());
    }

    /**
     * Sets the membership to true or false.
     * @param theMembership is a boolean value passed that is dependent
     *                      on whether the membership button was pressed
     */
    public void setMembership(final boolean theMembership) {
        myMembership = theMembership;
    }

    // Method made public only for testing purposes
    // Method Removed for second submission.
//    public boolean checkMyMembership() {
//       return myMembership;
//    }

    // Removed a comment
    // Updated some lines' length to please checkstyle
    // These changes made for submission 2
    /**
     * Calculates the total for the quantity of items, takes into
     * account membership status and bulk quantity sales.
     * @return BigDecimal
     */
    public BigDecimal calculateTotal() {
        BigDecimal totalValue = new BigDecimal("0");

        for (final Map.Entry<Item, Integer> item: myCart.entrySet()) {

            // If Membership is not selected,
            if (!myMembership || !(item.getKey().isBulk())) {
                totalValue = totalValue.add(BigDecimal.valueOf(
                        item.getValue()).multiply(item.getKey().getPrice()));
            }

            // If quantity is bulk and membership
            // is selected then temporary value is bulkPrice
            if (item.getKey().isBulk() && myMembership) {
                totalValue = totalValue.add(item.getKey().getBulkPrice().multiply(
                        BigDecimal.valueOf(
                                item.getValue() / item.getKey().getBulkQuantity())));
                totalValue = totalValue.add((BigDecimal.valueOf(
                        item.getValue() % item.getKey().getBulkQuantity())).multiply(
                                item.getKey().getPrice()));
            }
        }
        return totalValue.setScale(2, BigDecimal.ROUND_HALF_EVEN);
    }

    /**
     * Clears hashMap cart.
     */
    public void clear() {
        myCart.clear();
    }

    /**
     * Gets the size of the cart hash map.
     * @return myCart.size()
     */
    public int getCartSize() {
        return myCart.size();
    }

    // Updated toString for submission 2
    // so grammar is improved if there is more than
    // one item in quantity. Also added space variable
    // to fix checkstyle
    /**
     * Shares information about what is in your cart.
     * @return String
     */
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        final String space = " ";
        for (final Map.Entry<Item, Integer> item: myCart.entrySet()) {
            sb.append("Your Cart\n");
            if (myCart.isEmpty()) {
                sb.append("Is Empty! Please purchase some candy... :(");
            }
            sb.append("contains: ");
            sb.append(item.getValue());
            sb.append(space);
            sb.append(item.getKey());
            sb.append(space);
            if (item.getValue() > 1) {
                sb.append("items.");
            } else {
                sb.append("item.");
            }
        }

        return String.valueOf(sb);
    }

}
