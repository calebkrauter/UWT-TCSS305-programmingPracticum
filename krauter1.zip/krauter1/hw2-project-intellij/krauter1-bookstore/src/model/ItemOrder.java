/*
 * TCSS 305 Assignment 2 - UW Bookstore
 */

package model;

// Javadoc added for submission 2
/**
 * ItemOrder contains order information and is used in calculations
 * in the cart Class.
 *
 * @author Caleb Krauter
 * @version November, 02 2022
 */
public final class ItemOrder {

    // Javadoc added for submission 2
    /**
     * myItem represents the current Item of the instance at the class level.
     */
    private final Item myItem;

    // Javadoc added for submission 2
    /**
     * myQuantity represents the current quantity of the instance at the class level.
     */
    private final int myQuantity;

    // Javadoc added or updated for submission 2
    /**
     * Assigns class level fields.
     * @param theItem Item object passed in containing Item info
     * @param theQuantity the amount of Items
     */
    public ItemOrder(final Item theItem, final int theQuantity) {
        if (theItem == null) {
            throw new NullPointerException("The item passed to the constructor is null.");
        }
        if (theQuantity == 0) {
            throw new IllegalArgumentException("The quantity "
                    + "passed to the constructor is 0. :(");
        }

        myItem = theItem;
        myQuantity = theQuantity;

    }


    /**
     * Gets an Item.
     * @return myItem
     */
    public Item getItem() {
        return myItem;
    }

    /**
     * Gets a quantity.
     * @return myQuantity
     */
    public int getQuantity() {
        return myQuantity;
    }

    /**
     * Returns a string containing information about an order.
     * @return "You have made some orders! " + "You bought: " + getItem()
     */
    @Override
    public String toString() {
        return "You have made some orders! " + "You bought: " + getItem();
    }

}
