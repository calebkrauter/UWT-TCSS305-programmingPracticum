/*
 * TCSS 305 Assignment 2 - UW Bookstore
 */

package model;

import java.math.BigDecimal;
import java.util.Objects;

/**
 * This class works with ItemOrder, Cart and provided
 * classes to create a bookstore where a user may
 * register/login, choose quantity of items and at
 * which city and the total of the orders will be displayed
 * to the user.
 *
 * The Item class is given information that is
 * checked and saved at the class level for a given instance
 * so that it may be used from the ItemOrder class or Cart.
 *
 * @author Caleb Krauter
 * @version November, 2 2022
 */
public final class Item {

    // Javadoc added for submission 2
    /**
     * myName represents the name passed to a constructor
     * assigned to a class variable.
     */
    private final String myName;

    // Javadoc added for submission 2
    /**
     * myPrice represents the price passed to a constructor
     * assigned to a class variable.
     */
    private final BigDecimal myPrice;

    // Javadoc added for submission 2
    /**
     * Added Javadoc for Submission 2
     * myBulkQuantity represents the bulk quantity passed to a constructor
     * assigned to a class variable.
     */
    private int myBulkQuantity;

    // Javadoc added for submission 2
    /**
     * myBulkPrice represents the bulk price passed to a constructor
     * assigned to a class variable.
     */
    private BigDecimal myBulkPrice;

    // myNullName variable added for submission 2 to help with checkstyle
    // Javadoc for myNullName added for submission 2
    /**
     * myNullName is assigned the info printed when
     * throwing the NullPointerException for a name.
     */
    private final String myNullName = "The name passed to the constructor is null.";

    // myNullPrice variable added for submission 2 to help with checkstyle
    // Javadoc for myNullName added for submission 2
    /**
     * myNullPrice is assigned the info printed when
     * throwing the NullPointerException for a price.
     */
    private final String myNullPrice = "The price passed to the constructor is null.";

    // Item constructor is updated for submission 2,
    // Javadoc added for submission 2
    /**
     * Constructor checks if parameters passed are null and if they
     * are not then assigns them to variables.
     * @param theName current name passed into the current instance
     *               and assigned at class level
     * @param thePrice current price passed into the current instance
     *                 and assigned at class level
     */
    public Item(final String theName, final BigDecimal thePrice) {
        if (theName == null) {
            throw new NullPointerException(myNullName);
        }
        if (thePrice == null) {
            throw new NullPointerException(myNullPrice);
        }

        myName = theName;
        myPrice = thePrice;
    }

    // Throwing exceptions for null name and null price both use class level variables
    // that contain the necessary information so that
    // checkstyle is satisfied as of submission 2.
    // Javadoc added for submission 2
    /**
     * Constructor checks if parameters passed are null and if they
     * are not then assigns them to variables.
     * @param theName current name passed to current instance assigned at class level
     * @param thePrice current price passed to current instance assigned at class level
     * @param theBulkQuantity current bulk quantity passed to
     *                        current instance assigned at class level
     * @param theBulkPrice current bulk price passed to
     *                     current instance assigned at class level
     */
    public Item(final String theName, final BigDecimal thePrice, final int theBulkQuantity,
                final BigDecimal theBulkPrice) {
        if (theName == null) {
            throw new NullPointerException(myNullName);
        }
        if (thePrice == null) {
            throw new NullPointerException(myNullPrice);
        }
        if (theBulkQuantity == 0) {
            throw new IllegalArgumentException("The bulk quantity"
                    + " passed to the constructor is 0.");
        }
        if (theBulkPrice == null) {
            throw new NullPointerException("The bulk price "
                    + "passed to the constructor is null.");
        }
        myName = theName;
        myPrice = thePrice;        
        myBulkQuantity = theBulkQuantity;
        myBulkPrice = theBulkPrice;
    }

    /**
     * Gets a price.
     * @return myPrice
     */
    public BigDecimal getPrice() {
        return myPrice;
    }

    // Returns the bulk quantity for an item

    /**
     * Gets a bulk quantity.
     * @return myBulkQuantity
     */
    public int getBulkQuantity() {
        return myBulkQuantity;
    }

    /**
     * Gets a bulk price.
     * @return myBulkPrice
     */
    public BigDecimal getBulkPrice() {
        return myBulkPrice;
    }

    // Made private for submission 2
    /**
     * This helper method was originally made private but is
     * made public only for unit testing purposes. For submission 2
     * I have changed this method back to private to fit the
     * parameters of the assignment.
     * Gets a name.
     * @return myName
     */
    private String getName() {
        return myName;
    }

    /**
     * For Submission 2 I simplified the isBulk method to
     * fix a checkstyle error.
     * Returns true if the Item has bulk pricing otherwise false.
     * @return boolean
     */
    public boolean isBulk() {
        return getBulkPrice() != null;
    }

    /**
     * Returns information about the items for sale.
     *
     * @return String
     */
    @Override
    public String toString() {
        final StringBuilder buildString = new StringBuilder();
        buildString.append(getName());
        buildString.append(", ");
        buildString.append(getPrice());
        if (isBulk()) {
            buildString.append(" ");
            buildString.append("(");
            buildString.append(getBulkQuantity());
            buildString.append(" for $");
            buildString.append(getBulkPrice());
            buildString.append(")");
        }

        return buildString.toString();
    }

    /**
     * Checks if two objects are equal.
     * @param theOther is a second object passed
     * @return boolean
     */
    @Override
    public boolean equals(final Object theOther) {
        if (theOther == null || !getClass().equals(theOther.getClass())) {
            return false;
        }
        final Item otherItem = (Item) theOther;
        return myName.equalsIgnoreCase(otherItem.myName)
                && myPrice.equals(otherItem.myPrice);
    }

    /**
     * Returns a sometimes one of a kind value called
     * hashcode for an object that has a name and price.
     * @return int
     */
    @Override
    public int hashCode() {
        return Objects.hash(myName, myPrice);
    }

}
