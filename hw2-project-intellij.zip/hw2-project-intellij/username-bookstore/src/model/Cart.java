// Finish and comment me!

package model;

import java.math.BigDecimal;

public class Cart {


    public Cart() {

    }
    

    public void add(final ItemOrder theOrder) {

    }

    
    public void setMembership(final boolean theMembership) {

    }


    public BigDecimal calculateTotal() {
        
        return null;
    }
    
    
    public void clear() {
        
    }
    
    
    public int getCartSize() {
        return -1;
    }


    @Override
    public String toString() {
        return null;
    }

}
