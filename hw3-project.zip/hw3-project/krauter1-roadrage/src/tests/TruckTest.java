package tests;

import model.Direction;
import model.Light;
import model.Terrain;
import model.Truck;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TruckTest {
    private static final int RANDOMNESS_INDEX = 100;

    @Test
    public void testTruckConstructor() {
        final Truck myTruck = new Truck(10, 11, Direction.NORTH);

        assertEquals(10, myTruck.getX(), "Truck x coordinate not initialized properly.");
        assertEquals(11, myTruck.getY(), "Truck y coordinate not initialized properly.");
        assertEquals(Direction.NORTH, myTruck.getDirection(), "Truck direction not initialized properly. Expected North");
        assertEquals(0, myTruck.getDeathTime(), "Truck should not have died.");
        assertTrue(myTruck.isAlive(), "Truck started off dead. isAlive() did not initialize to true.");
    }

    @Test
    public void testTruckSetters() {
        final Truck myTruck = new Truck(10,11, Direction.NORTH);
        myTruck.setX(99);
        assertEquals(99, myTruck.getX(), "Truck setX failed.");
        myTruck.setY(100);
        assertEquals(100, myTruck.getY(), "Truck setY failed.");
        myTruck.setDirection(Direction.SOUTH);
        assertEquals(Direction.SOUTH, myTruck.getDirection(), "Truck setDirection failed.");
    }

    @Test
    public void testCanPass() {

        final List<Terrain> validTerrain = new ArrayList<>();
        validTerrain.add(Terrain.STREET);
        validTerrain.add(Terrain.CROSSWALK);
        validTerrain.add(Terrain.LIGHT);

        final Truck truck = new Truck(0, 0, Direction.NORTH);

        for (final Terrain projectedTerrain : Terrain.values()) {
            for (final Light currentLightCondition : Light.values()) {
                if (projectedTerrain == Terrain.STREET) {
                    // A truck can pass a street with any light condition.
                    assertTrue(truck.canPass(projectedTerrain, currentLightCondition)
                            , "Truck can pass on street with any "
                                    + "light, current light " + currentLightCondition);
                } else if (projectedTerrain == Terrain.LIGHT) {
                    assertTrue(truck.canPass(projectedTerrain, currentLightCondition)
                            , "Truck passes through all light colors, current color is "
                                    + currentLightCondition);
                } else if (projectedTerrain == Terrain.CROSSWALK) {
                    if (currentLightCondition != Light.RED) {
                        assertTrue(truck.canPass(projectedTerrain, currentLightCondition)
                                , "Truck can pass crosswalks right now, when light is"
                                        + " Green or Yellow not Red. Light color is currently "
                                        + currentLightCondition);
                    } else if (currentLightCondition == Light.RED) {
                        assertFalse(truck.canPass(projectedTerrain, currentLightCondition)
                                , "Truck can't pass crosswalk when light is red."
                                        + " Current light color is " + currentLightCondition);
                    }
                }
            }
        }
    }

    @Test
    public void testChooseDirectionSurroundedByStreet() {
        final Map<Direction, Terrain> theNeighbors = new HashMap<Direction, Terrain>();
        theNeighbors.put(Direction.WEST, Terrain.STREET);
        theNeighbors.put(Direction.NORTH, Terrain.STREET);
        theNeighbors.put(Direction.EAST, Terrain.STREET);
        theNeighbors.put(Direction.SOUTH, Terrain.STREET);

        boolean seenWest = false;
        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenSouth = false;

        final Truck truck = new Truck(0, 0, Direction.NORTH);

        for (int i = 0; i < RANDOMNESS_INDEX; i++) {
            final Direction myDirection = truck.chooseDirection(theNeighbors);

            if (myDirection == Direction.WEST) {
                seenWest = true;
            } else if (myDirection == Direction.NORTH) {
                seenNorth = true;
            } else if (myDirection == Direction.EAST) {
                seenEast = true;
            } else if (myDirection == Direction.SOUTH) {
                seenSouth = true;
            }
        }

        assertTrue(seenWest && seenNorth && seenEast
                , "Truck chooseDirection() is not randomly "
                        + " choosing a valid direction.");
        assertFalse(seenSouth, "Truck chooseDirection reversed "
                + "Unnecessarily.");
    }
    @Test
    public void testChooseDirectionSurroundedByLight() {
        final Map<Direction, Terrain> theNeighbors = new HashMap<Direction, Terrain>();
        theNeighbors.put(Direction.WEST, Terrain.LIGHT);
        theNeighbors.put(Direction.NORTH, Terrain.LIGHT);
        theNeighbors.put(Direction.EAST, Terrain.LIGHT);
        theNeighbors.put(Direction.SOUTH, Terrain.LIGHT);

        boolean seenWest = false;
        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenSouth = false;

        final Truck truck = new Truck(0, 0, Direction.NORTH);

        for (int i = 0; i < RANDOMNESS_INDEX; i++) {
            final Direction myDirection = truck.chooseDirection(theNeighbors);

            if (myDirection == Direction.WEST) {
                seenWest = true;
            } else if (myDirection == Direction.NORTH) {
                seenNorth = true;
            } else if (myDirection == Direction.EAST) {
                seenEast = true;
            } else if (myDirection == Direction.SOUTH) {
                seenSouth = true;
            }
        }

        assertTrue(seenWest && seenNorth && seenEast
                , "Truck chooseDirection() is not randomly "
                        + " choosing a valid direction.");
        assertFalse(seenSouth, "Truck chooseDirection reversed "
                + "Unnecessarily.");
    }
    @Test
    public void testChooseDirectionSurroundedByCrossWalk() {
        final Map<Direction, Terrain> theNeighbors = new HashMap<Direction, Terrain>();
        theNeighbors.put(Direction.WEST, Terrain.CROSSWALK);
        theNeighbors.put(Direction.NORTH, Terrain.CROSSWALK);
        theNeighbors.put(Direction.EAST, Terrain.CROSSWALK);
        theNeighbors.put(Direction.SOUTH, Terrain.CROSSWALK);

        boolean seenWest = false;
        boolean seenNorth = false;
        boolean seenEast = false;
        boolean seenSouth = false;

        final Truck truck = new Truck(0, 0, Direction.NORTH);

        for (int i = 0; i < RANDOMNESS_INDEX; i++) {
            final Direction myDirection = truck.chooseDirection(theNeighbors);

            if (myDirection == Direction.WEST) {
                seenWest = true;
            } else if (myDirection == Direction.NORTH) {
                seenNorth = true;
            } else if (myDirection == Direction.EAST) {
                seenEast = true;
            } else if (myDirection == Direction.SOUTH) {
                seenSouth = true;
            }
        }

        assertTrue(seenWest && seenNorth && seenEast
                , "Truck chooseDirection() is not randomly "
                        + " choosing a valid direction.");
        assertFalse(seenSouth, "Truck chooseDirection reversed "
                + "Unnecessarily.");
    }

    @Test
    public void testChooseDirectionMustReverse() {
        for (final Terrain myTerrain : Terrain.values()) {

            // Testing private helper method logic when it returns false.
            if (!(myTerrain == Terrain.STREET
                    || myTerrain == Terrain.LIGHT
                    || myTerrain == Terrain.CROSSWALK)) {

                final Map<Direction, Terrain> myNeighbors
                        = new HashMap<Direction, Terrain>();
                myNeighbors.put(Direction.WEST, myTerrain);
                myNeighbors.put(Direction.NORTH, myTerrain);
                myNeighbors.put(Direction.EAST, myTerrain);
                myNeighbors.put(Direction.SOUTH, Terrain.STREET);

                final Truck truck = new Truck(0, 0, Direction.NORTH);
                assertEquals(Direction.SOUTH, truck.chooseDirection(myNeighbors)
                        , "Truck chooseDirection() returned a reverse direction.");
            }
        }
    }

    @Test
    public void testCheckTerrain() {
        Truck truck1 = new Truck(0, 0, Direction.NORTH);
        assertTrue(truck1.checkTerrain(Terrain.STREET), "Street can't be passed");
        assertTrue(truck1.checkTerrain(Terrain.LIGHT), "Light can't be passed");
        assertTrue(truck1.checkTerrain(Terrain.CROSSWALK), "Crosswalk can't be passed");
        assertFalse(truck1.checkTerrain(Terrain.TRAIL), "Trail can be passed and shouldn't be passed.");
        assertFalse(truck1.checkTerrain(Terrain.WALL), "Wall can be passed and shouldn't be passed.");
        assertFalse(truck1.checkTerrain(Terrain.GRASS), "Grass can be passed and shouldn't be passed.");
    }
}