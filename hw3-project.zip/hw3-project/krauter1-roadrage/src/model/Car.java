/*
 * TCSS 305 Assignment 3 - Roadrage
 */
package model;

import java.util.Map;

/**
 * Car finds passable terrains and chooses a direction
 * per the assignment specifications.
 *
 * @author Caleb Krauter
 * @version November, 15 2022
 */
public class Car extends AbstractVehicle implements Vehicle {


    /**
     * Static field time to death.
     */
    private static final int MY_DEATH_TIME = 15;

    /**
     * Constructor takes in values and sends values to
     * the parent.
     * @param theX current x-coordinate
     * @param theY current y-coordinate
     * @param theDir current direction
     */
    public Car(final int theX,
                 final int theY, final Direction theDir) {
        super(theDir, theX, theY, MY_DEATH_TIME);
    }

    /**
     * Checks if the terrain is passable during a given light
     * condition.
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return boolean
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain == Terrain.STREET
            || theTerrain == Terrain.LIGHT && theLight != Light.RED
            || theTerrain == Terrain.CROSSWALK && theLight == Light.GREEN;
    }

    /**
     * Checks if the terrain is passable.
     * @param theTerrain current terrain
     * @return boolean
     */
    private boolean checkTerrain(final Terrain theTerrain) {
        return theTerrain == Terrain.STREET
            || theTerrain == Terrain.LIGHT
            || theTerrain == Terrain.CROSSWALK;
    }

    /**
     * Chooses direction based on assignment specifications.
     * @param theNeighbors The map of neighboring terrain.
     * @return Direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        Direction direction = getDirection();

        if (checkTerrain(theNeighbors.get(direction))) {
            direction = getDirection();
        } else if (checkTerrain(theNeighbors.get(direction.left()))) {
            direction = direction.left();
        } else if (checkTerrain(theNeighbors.get(direction.right()))) {
            direction = direction.right();
        } else {
            direction = direction.reverse();
        }

        return direction;
    }

}
