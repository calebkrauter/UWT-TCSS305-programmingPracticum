/*
 * TCSS 305 Assignment 3 - Roadrage
 */
package model;

import java.util.ArrayList;
import java.util.Map;

/**
 * Human finds passable terrains and chooses a direction
 * per the assignment specifications.
 *
 * @author Caleb Krauter
 * @version November, 15 2022
 */
public class Human extends AbstractVehicle implements Vehicle {

    /**
     * Static field time to death.
     */
    private static final int MY_DEATH_TIME = 45;

    /**
     * Constructor takes in values and sends values to
     * the parent.
     * @param theX current x-coordinate
     * @param theY current y-coordinate
     * @param theDir current direction
     */
    public Human(final int theX,
                 final int theY, final Direction theDir) {
        super(theDir, theX, theY, MY_DEATH_TIME);
    }

    /**
     * Checks if the terrain is passable during a given light
     * condition.
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return boolean
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain == Terrain.GRASS
            || theTerrain == Terrain.CROSSWALK && theLight != Light.GREEN;
    }

    /**
     * Checks if the terrain is passable.
     * @param theTerrain current terrain
     * @return boolean
     */
    public boolean checkTerrain(final Terrain theTerrain) {
        return theTerrain == Terrain.GRASS
            || theTerrain == Terrain.CROSSWALK;
    }

    // PMD says that my code should only have one return exit point.
    // In this case I am choosing not to do this, I don't believe it is necessary
    // it is more stylistic I believe. I also am not convinced that this is a good
    // situation for a single return.
    // PMD also has some issues with LawOfDemeter about using entry as I have in my
    // For each loop. I don't know how to fix this, and don't believe I need to.
    // PMD also shows a dataFlowAnomaly warning which is not a bug and likely unimportant,
    // I also don’t know how to fix it.
    /**
     * Chooses direction based on assignment specifications.
     * @param theNeighbors The map of neighboring terrain.
     * @return Direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        final ArrayList<Direction> arrayList = new ArrayList<>();
        for (final Map.Entry<Direction, Terrain> entry : theNeighbors.entrySet()) {
            if (checkTerrain(entry.getValue()) && entry.getValue().equals(Terrain.CROSSWALK)
                    && !(entry.getKey().equals(getDirection().reverse()))) {
                return entry.getKey();
            }
            if (checkTerrain(entry.getValue())
                    && !entry.getKey().equals(getDirection().reverse())) {
                arrayList.add(entry.getKey());
            }
        }
        if (arrayList.isEmpty()) {
            arrayList.add(getDirection().reverse());
        }

        return arrayList.get((int) (Math.random() * arrayList.size()));
    }

}
