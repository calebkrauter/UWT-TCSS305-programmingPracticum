/*
 * TCSS 305 Assignment 3 - Roadrage
 */
package model;

/**
 * Taxi finds passable terrains and chooses a direction
 * per the assignment specifications.
 *
 * @author Caleb Krauter
 * @version November, 15 2022
 */
public class Taxi extends Car implements Vehicle {

    /**
     * Static field time until patience has run out.
     */
    private static int myImpatienceTimer;

    /**
     * Constructor takes in values and sends values to
     * the parent.
     * @param theX current x-coordinate
     * @param theY current y-coordinate
     * @param theDir current direction
     */
    public Taxi(final int theX,
                final int theY, final Direction theDir) {
        super(theX, theY, theDir);

        // PMD warning about AssignmetnToNonFinalStatic for myImpatienceTimer = 0;
        // Not sure how to fix warning.
        myImpatienceTimer = 0;
    }

    /**
     * Checks if the terrain is passable during a given light
     * condition.
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return boolean
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain == Terrain.STREET
                || theTerrain == Terrain.LIGHT && theLight != Light.RED
                || theTerrain == Terrain.CROSSWALK && theLight != Light.RED
                || theTerrain == Terrain.CROSSWALK && myDriverPatienceRanOut(theLight);
    }

    /**
     * Checks if patience has run out.
     * @param theLight current light condition.
     * @return boolean
     */
    private boolean myDriverPatienceRanOut(final Light theLight) {
        myImpatienceTimer++;

        // PMD calls for variable int myTime to be final
        // and contradictory to avoid final here. The AvoidFinalLocalVariable
        // has a note saying that this warning will be removed in an update.
        final int time = 3;

        // DataflowAnomallyAnalysis says that this rule is deprecated
        // and does not have to be a bug. I don't know how to fix it
        // and I don't think it is something I need to fix.
        boolean check = false;
        if (myImpatienceTimer == time) {
            myImpatienceTimer = 0;
            check = true;
        }
        if (theLight != Light.RED) {
            myImpatienceTimer = 0;
        }
        return check;
    }

}
