/*
 * TCSS 305 Assignment 3 - Roadrage
 */
package model;

import java.util.ArrayList;
import java.util.Map;

// Instead of implementing vehicle here could I make
// Abstract methods of the canPass and chooseDirection
// and implement those here through the AbstractVehicle class?

/**
 * Truck finds passable terrains and chooses a direction
 * per the assignment specifications.
 *
 * @author Caleb Krauter
 * @version November, 15 2022
 */

public class Truck extends AbstractVehicle {

    /**
     * Static field time to death.
     */
    private static final int MY_DEATH_TIME = 0;

    /**
     * Constructor takes in values and sends values to
     * the parent.
     * @param theX current x-coordinate
     * @param theY current y-coordinate
     * @param theDir current direction
     */
    public Truck(final int theX,
                 final int theY, final Direction theDir) {

        super(theDir, theX, theY, MY_DEATH_TIME);
    }

    /**
     * Checks if the terrain is passable during a given light
     * condition.
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return boolean
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain == Terrain.STREET
                || theTerrain == Terrain.LIGHT
                || theTerrain == Terrain.CROSSWALK
                && theLight != Light.RED;
    }

    /**
     * Checks if the terrain is passable.
     * @param theTerrain current terrain
     * @return boolean
     */
    public boolean checkTerrain(final Terrain theTerrain) {
        return theTerrain == Terrain.STREET
            || theTerrain == Terrain.LIGHT
            || theTerrain == Terrain.CROSSWALK;
    }

    /**
     * Chooses direction based on assignment specifications.
     * @param theNeighbors The map of neighboring terrain.
     * @return Direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        final ArrayList<Direction> arrayList = new ArrayList<>();
        theNeighbors.forEach((key, value) -> {
            if (checkTerrain(value)
                    && !(key.equals(getDirection().reverse()))) {
                arrayList.add(key);
            }
        });
        // Not sure how to approach getting rid of PMD error for line 55.
        // I tried the suggestions and got more pmd errors so the way I have it,
        // allows for the least PMD warnings.
        if (arrayList.isEmpty()) {
            arrayList.add(getDirection().reverse());
        }

        return arrayList.get((int) (Math.random() * arrayList.size()));
    }

}
