/*
 * TCSS 305 Assignment 3 - Roadrage
 */
package model;

import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;

/**
 * Atv finds passable terrains and chooses a direction
 * per the assignment specifications.
 *
 * @author Caleb Krauter
 * @version November, 15 2022
 */
public class Atv extends AbstractVehicle implements Vehicle {

    /**
     * Static field time to death.
     */
    private static final int MY_DEATH_TIME = 25;

    /**
     * Constructor takes in values and sends values to
     * the parent.
     * @param theX current x-coordinate
     * @param theY current y-coordinate
     * @param theDir current direction
     */
    public Atv(final int theX,
               final int theY, final Direction theDir) {
        super(theDir, theX, theY, MY_DEATH_TIME);
    }

    /**
     * Checks if the terrain is passable during a given light
     * condition.
     * @param theTerrain The terrain.
     * @param theLight The light color.
     * @return boolean
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain != Terrain.WALL;
    }

    /**
     * Checks if the terrain is passable.
     * @param theTerrain current terrain
     * @return boolean
     */
    private boolean checkTerrain(final Terrain theTerrain) {
        return theTerrain != Terrain.WALL;
    }

    // Has LawOfDemeter warning, not sure how I should fix it. Maybe by changing
    // getDirection.reverse() to entry.getKey().reverse() but I don't believe that
    // would work properly and what I have now should function fine.
    /**
     * Chooses direction based on assignment specifications.
     * @param theNeighbors The map of neighboring terrain.
     * @return Direction
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {

        final ArrayList<Direction> arrayList = new ArrayList<>();
        for (final Map.Entry<Direction, Terrain> entry : theNeighbors.entrySet()) {
            if (checkTerrain(entry.getValue())
                    && !(Objects.equals(entry.getKey(), getDirection().reverse()))) {
                arrayList.add(entry.getKey());
            }
        }
        return arrayList.get((int) (Math.random() * arrayList.size()));
    }
}
