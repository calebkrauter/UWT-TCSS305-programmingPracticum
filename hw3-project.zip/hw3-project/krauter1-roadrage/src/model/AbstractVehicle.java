/*
 * TCSS 305 Assignment 3 - Roadrage
 */
package model;

import java.util.Locale;

/**
 * AbstractVehicle implements vehicle and contains attributes (methods)
 * that either all or most vehicles have in common.
 *
 * @author Caleb Krauter
 * @version November, 15 2022
 */
public abstract class AbstractVehicle implements Vehicle {
    // AbstractVehicle has some BeanMembersShouldSerialize violations.
    // I don't believe it is vital enough and I don't know how to fix.

    /**
     * Instance field for current direction.
     */
    private Direction myDirection;

    /**
     * Instance field for current x value.
     */
    private int myX;

    /**
     * Instance field for current y value.
     */
    private int myY;

    /**
     * Instance field for current life status initialized to true.
     */
    private boolean myLifeExists = true;

    /**
     * Instance field for time to death.
     */
    private final int myDeathTime;

    /**
     * Instance field for initial x.
     */
    private final int myInitialX;

    /**
     * Instance field for initial y.
     */
    private final int myInitialY;

    /**
     * Instance field for initial direction.
     */
    private final Direction myInitialDir;

    /**
     * Instance field for pokes.
     */
    private int myPokes;

    // PMD Not sure how to fix CommentDefaultAccessModifier violation.

    /**
     * AbstractVehicle constructor that takes in values and initializes
     * fields.
     * @param theDir passed in direction for the instance
     * @param theX passed in x for the instance
     * @param theY passed in y for the instance
     * @param theDeathTime passed in time to death for the instance
     */
    AbstractVehicle(final Direction theDir, final int theX,
                    final int theY, final int theDeathTime) {
        myInitialDir = theDir;
        myInitialX = theX;
        myInitialY = theY;
        myDeathTime = theDeathTime;
        myPokes = 0;
        reset();
    }

    /**
     * Collide determines when a vehicle should die
     * after running into a vehicle stronger than it.
     * @param theOther The other object.
     */
    @Override
    public void collide(final Vehicle theOther) {
        if (isAlive() && theOther.isAlive() && getDeathTime()
                > theOther.getDeathTime()) {
            myLifeExists = false;
        }
    }

    /**
     * Gets time to death.
     * @return myDeathTime
     */
    @Override
    public int getDeathTime() {
        return myDeathTime;
    }

    // PMD warnings about LawOfDemeter and this method is the same or very similar
    // to what Tom gave us in class.

    /**
     * Gets image file name.
     * @return string builder as a string
     */
    @Override
    public String getImageFileName() {
        final StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(getClass().getSimpleName().toLowerCase(Locale.US));
        if (!isAlive()) {
            stringBuilder.append("_dead");
        }
        stringBuilder.append(".gif");
        return stringBuilder.toString();
    }

    /**
     * Gets direction.
     * @return myDirection
     */
    @Override
    public Direction getDirection() {
        return myDirection;
    }

    /**
     * Gets x.
     * @return myX
     */
    @Override
    public int getX() {
        return myX;
    }

    /**
     * Gets y.
     * @return myY
     */
    @Override
    public int getY() {
        return myY;
    }

    /**
     * Checks life status.
     * @return boolean myLifeExists
     */
    @Override
    public boolean isAlive() {
        return myLifeExists;
    }

    /**
     * Pokes dead vehicles and resets counter.
     */
    @Override
    public void poke() {
        if (!myLifeExists) {
            myPokes++;
        }
        if (myPokes % myDeathTime == 0) {
            myPokes = 0;
            myLifeExists = true;
        }
    }

    /**
     * Resets coordinates,
     * direction and myLifeExists to true.
     */
    @Override
    public void reset() {
        myX = myInitialX;
        myY = myInitialY;
        myDirection = myInitialDir;
        myLifeExists = true;
    }

    /**
     * Sets the direction.
     * @param theDir The new direction.
     */
    @Override
    public void setDirection(final Direction theDir) {
        myDirection = theDir;
    }

    /**
     * Sets the x-coordinate.
     * @param theX The new x-coordinate.
     */
    @Override
    public void setX(final int theX) {
        myX = theX;
    }

    /**
     * Sets the y-coordinate.
     * @param theY The new t-coordinate.
     */
    @Override
    public void setY(final int theY) {
        myY = theY;
    }
}
